<?php
echo"este es el archivo de contacto.php";
?>
