<?php
echo "Soy el codigo del archivo index.php";
echo ""
?>
