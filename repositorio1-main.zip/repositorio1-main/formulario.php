<?php
echo"este es el archivo de formulario.php";
?>
